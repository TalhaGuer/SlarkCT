#pragma once
#include <cstdint>

// cs2-dumper 2026-11 offset'leri
// Guncel degiller ise cs2-dumper ciktisini buraya yansit
namespace Offsets {
    // client.dll
    constexpr std::ptrdiff_t dwEntityList       = 0x18C2C38;
    constexpr std::ptrdiff_t dwLocalPlayerPawn  = 0x17397F8;
    constexpr std::ptrdiff_t dwViewMatrix       = 0x19D09F0;

    // entity field offset'leri
    constexpr std::ptrdiff_t m_iHealth          = 0x334;
    constexpr std::ptrdiff_t m_iTeamNum         = 0x3CB;
    constexpr std::ptrdiff_t m_pGameSceneNode   = 0x310;
    constexpr std::ptrdiff_t m_modelState       = 0x160;
    constexpr std::ptrdiff_t m_boneArray        = 0x80;
    constexpr std::ptrdiff_t m_pWeaponServices  = 0x1130;
    constexpr std::ptrdiff_t m_hMyWeapons       = 0xE00;

    // CEconItemView
    constexpr std::ptrdiff_t m_AttributeManager     = 0x68;
    constexpr std::ptrdiff_t m_Item                 = 0x68;
    constexpr std::ptrdiff_t m_iItemDefinitionIndex = 0x1B8;
    constexpr std::ptrdiff_t m_iItemIDHigh          = 0x48;
    constexpr std::ptrdiff_t m_nFallbackPaintKit    = 0x9BC;
    constexpr std::ptrdiff_t m_flFallbackWear       = 0x9C0;
    constexpr std::ptrdiff_t m_nFallbackSeed        = 0x9C4;
    constexpr std::ptrdiff_t m_nFallbackStatTrak    = 0x9C8;
}
