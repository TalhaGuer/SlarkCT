#pragma once
#include <Windows.h>
#include <cstdint>
#include <cstring>

inline std::uintptr_t GetModuleBase(const char* name) {
    return reinterpret_cast<std::uintptr_t>(GetModuleHandleA(name));
}

template<typename T>
inline T Read(std::uintptr_t addr) {
    if (!addr) return T{};
    T val{};
    std::memcpy(&val, reinterpret_cast<void*>(addr), sizeof(T));
    return val;
}

template<typename T>
inline void Write(std::uintptr_t addr, T val) {
    if (!addr) return;
    std::memcpy(reinterpret_cast<void*>(addr), &val, sizeof(T));
}

inline std::uintptr_t ReadPtr(std::uintptr_t addr) {
    return Read<std::uintptr_t>(addr);
}
