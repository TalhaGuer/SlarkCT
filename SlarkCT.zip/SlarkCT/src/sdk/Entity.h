#pragma once
#include <cstdint>
#include "Memory.h"
#include "Offsets.h"

struct Vector3 {
    float x, y, z;
};

struct Matrix4x4 {
    float m[4][4];
};

struct BoneData {
    float x, y, z;
    char  pad[20];
};

class Entity {
public:
    std::uintptr_t ptr;

    explicit Entity(std::uintptr_t p) : ptr(p) {}

    bool valid() const { return ptr != 0; }

    int health() const {
        return Read<int>(ptr + Offsets::m_iHealth);
    }

    int team() const {
        return Read<int>(ptr + Offsets::m_iTeamNum);
    }

    bool isAlive() const {
        int hp = health();
        return hp > 0 && hp <= 100;
    }

    Vector3 origin() const {
        auto sceneNode = ReadPtr(ptr + Offsets::m_pGameSceneNode);
        if (!sceneNode) return {};
        return Read<Vector3>(sceneNode + 0xC0);
    }

    // head = bone 6, feet = origin
    Vector3 bonePos(int boneIdx) const {
        auto sceneNode = ReadPtr(ptr + Offsets::m_pGameSceneNode);
        if (!sceneNode) return {};
        auto boneArray = ReadPtr(sceneNode + Offsets::m_modelState + Offsets::m_boneArray);
        if (!boneArray) return {};
        return Read<Vector3>(boneArray + boneIdx * sizeof(BoneData));
    }
};

// global entity list pointer — Hooks.cpp'de set edilir
extern std::uintptr_t g_EntityList;

inline Entity GetEntity(int idx) {
    if (!g_EntityList) return Entity(0);
    auto listEntry = ReadPtr(g_EntityList + (idx >> 9) * 8 + 16);
    if (!listEntry) return Entity(0);
    auto entityPtr = ReadPtr(listEntry + 120 * (idx & 0x1FF));
    return Entity(entityPtr);
}
