#pragma once
#include <cstdint>
#include <array>

namespace SkinChanger {
    struct WeaponSkin {
        bool  enabled  = false;
        int   paintKit = 0;
        float wear     = 0.001f;
        int   seed     = 0;
        int   statTrak = -1; // -1 = kapali
    };

    // weapon definition index -> skin config
    // ornek: AK47 = 7, M4A1-S = 60, AWP = 9
    extern std::array<WeaponSkin, 128> skins;

    void Run(std::uintptr_t localPawn);
}
