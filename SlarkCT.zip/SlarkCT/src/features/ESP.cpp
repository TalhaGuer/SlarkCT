#include "ESP.h"
#include "../render/Renderer.h"

ESP::Config ESP::cfg;

void ESP::Run(ImDrawList* dl, const Matrix4x4& viewMatrix,
              int screenW, int screenH, std::uintptr_t localPawn) {
    if (!cfg.enabled || !localPawn) return;

    int localTeam = Entity(localPawn).team();

    for (int i = 1; i < 64; ++i) {
        Entity ent = GetEntity(i);
        if (!ent.valid() || ent.ptr == localPawn) continue;
        if (!ent.isAlive()) continue;
        if (cfg.teamCheck && ent.team() == localTeam) continue;

        Vector3 head = ent.bonePos(6);
        Vector3 feet = ent.origin();
        if (head.x == 0.f && head.y == 0.f) continue;

        feet.z -= 9.f;

        ImVec2 screenHead, screenFeet;
        if (!Renderer::WorldToScreen(head, screenHead, viewMatrix, screenW, screenH)) continue;
        if (!Renderer::WorldToScreen(feet, screenFeet, viewMatrix, screenW, screenH)) continue;

        // cok kucuk veya ekran disiysa atla
        float boxH = screenFeet.y - screenHead.y;
        if (boxH < 5.f || boxH > screenH) continue;

        if (cfg.showBox)
            Renderer::DrawBox(dl, screenHead, screenFeet,
                              IM_COL32(255, 50, 50, 230));

        if (cfg.showHealth)
            Renderer::DrawHealthBar(dl, screenHead, screenFeet, ent.health());

        if (cfg.showName)
            Renderer::DrawName(dl, screenHead, ent.health());
    }
}
