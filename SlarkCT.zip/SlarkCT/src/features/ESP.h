#pragma once
#include "imgui.h"
#include "../sdk/Entity.h"

namespace ESP {
    struct Config {
        bool enabled   = true;
        bool showBox   = true;
        bool showHealth= true;
        bool showName  = true;
        bool teamCheck = true;
    };

    extern Config cfg;

    void Run(ImDrawList* dl, const Matrix4x4& viewMatrix,
             int screenW, int screenH, std::uintptr_t localPawn);
}
