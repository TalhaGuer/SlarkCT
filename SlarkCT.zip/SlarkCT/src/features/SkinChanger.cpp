#include "SkinChanger.h"
#include "../sdk/Memory.h"
#include "../sdk/Offsets.h"
#include "../sdk/Entity.h"

std::array<SkinChanger::WeaponSkin, 128> SkinChanger::skins{};

void SkinChanger::Run(std::uintptr_t localPawn) {
    if (!localPawn) return;

    auto weaponServices = ReadPtr(localPawn + Offsets::m_pWeaponServices);
    if (!weaponServices) return;

    // CUtlVector<CEntityHandle> m_hMyWeapons
    auto vecData = ReadPtr(weaponServices + Offsets::m_hMyWeapons);
    int  vecSize = Read<int>(weaponServices + Offsets::m_hMyWeapons + 0x10);
    if (!vecData || vecSize <= 0) return;

    for (int i = 0; i < vecSize && i < 8; ++i) {
        auto handle = Read<std::uint32_t>(vecData + i * 4);
        if (handle == 0xFFFFFFFF) continue;

        // handle resolve
        auto listEntry = ReadPtr(g_EntityList + (handle >> 9) * 8 + 16);
        if (!listEntry) continue;
        auto weaponPtr = ReadPtr(listEntry + 120 * (handle & 0x1FF));
        if (!weaponPtr) continue;

        // m_iItemDefinitionIndex
        auto econItem = weaponPtr + Offsets::m_AttributeManager + Offsets::m_Item;
        int  defIdx   = Read<std::uint16_t>(econItem + Offsets::m_iItemDefinitionIndex);
        if (defIdx <= 0 || defIdx >= 128) continue;

        auto& skin = skins[defIdx];
        if (!skin.enabled) continue;

        // custom item flag + fallback field'lari yaz
        Write<std::uint32_t>(weaponPtr + Offsets::m_iItemIDHigh,      0xFFFFFFFF);
        Write<int>          (weaponPtr + Offsets::m_nFallbackPaintKit, skin.paintKit);
        Write<float>        (weaponPtr + Offsets::m_flFallbackWear,    skin.wear);
        Write<int>          (weaponPtr + Offsets::m_nFallbackSeed,     skin.seed);
        Write<int>          (weaponPtr + Offsets::m_nFallbackStatTrak, skin.statTrak);
    }
}
