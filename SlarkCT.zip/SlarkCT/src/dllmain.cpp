#include <Windows.h>
#include "hooks/Hooks.h"

static HMODULE g_hModule = nullptr;

static DWORD WINAPI MainThread(LPVOID) {
    // CS2 yuklenmesini bekle
    while (!GetModuleHandleA("client.dll"))
        Sleep(100);
    Sleep(500); // biraz daha bekle, stable olsun

    if (!Hooks::Init()) {
        FreeLibraryAndExitThread(g_hModule, 1);
        return 1;
    }

    // END = eject
    while (!(GetAsyncKeyState(VK_END) & 1))
        Sleep(50);

    Hooks::Shutdown();
    Sleep(100);

    FreeLibraryAndExitThread(g_hModule, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_hModule = hModule;
        DisableThreadLibraryCalls(hModule);
        CloseHandle(CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr));
    }
    return TRUE;
}
