#pragma once
#include <d3d11.h>
#include <dxgi.h>

namespace Hooks {
    using PresentFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT);

    extern PresentFn            oPresent;
    extern ID3D11Device*        g_Device;
    extern ID3D11DeviceContext* g_Context;
    extern ID3D11RenderTargetView* g_RTV;
    extern HWND                 g_Hwnd;

    bool Init();
    void Shutdown();

    HRESULT __stdcall hkPresent(IDXGISwapChain* chain, UINT syncInterval, UINT flags);
}
