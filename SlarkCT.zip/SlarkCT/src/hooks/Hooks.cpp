#include "Hooks.h"
#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "../features/ESP.h"
#include "../features/SkinChanger.h"
#include "../sdk/Memory.h"
#include "../sdk/Offsets.h"
#include "../sdk/Entity.h"

// globals
Hooks::PresentFn            Hooks::oPresent  = nullptr;
ID3D11Device*               Hooks::g_Device  = nullptr;
ID3D11DeviceContext*        Hooks::g_Context = nullptr;
ID3D11RenderTargetView*     Hooks::g_RTV     = nullptr;
HWND                        Hooks::g_Hwnd    = nullptr;

std::uintptr_t g_EntityList = 0;
static std::uintptr_t s_Client = 0;
static bool g_ImguiInit = false;
static IDXGISwapChain* g_Chain = nullptr;

// weapon defIdx isim tablosu (menu icin)
static const char* WeaponName(int idx) {
    switch (idx) {
        case 1:  return "Desert Eagle";
        case 2:  return "Dual Berettas";
        case 3:  return "Five-SeveN";
        case 4:  return "Glock-18";
        case 7:  return "AK-47";
        case 8:  return "AUG";
        case 9:  return "AWP";
        case 10: return "FAMAS";
        case 11: return "G3SG1";
        case 13: return "Galil AR";
        case 14: return "M249";
        case 16: return "M4A4";
        case 17: return "MAC-10";
        case 19: return "P90";
        case 23: return "MP5-SD";
        case 24: return "UMP-45";
        case 25: return "XM1014";
        case 26: return "PP-Bizon";
        case 27: return "MAG-7";
        case 28: return "Negev";
        case 29: return "Sawed-Off";
        case 30: return "Tec-9";
        case 32: return "P2000";
        case 33: return "MP7";
        case 34: return "MP9";
        case 35: return "Nova";
        case 36: return "P250";
        case 38: return "SCAR-20";
        case 39: return "SG 553";
        case 40: return "SSG 08";
        case 60: return "M4A1-S";
        case 61: return "USP-S";
        case 63: return "CZ75-Auto";
        case 64: return "R8 Revolver";
        default: return nullptr;
    }
}

static void InitImgui(IDXGISwapChain* chain) {
    chain->GetDevice(__uuidof(ID3D11Device),
                     reinterpret_cast<void**>(&Hooks::g_Device));
    Hooks::g_Device->GetImmediateContext(&Hooks::g_Context);

    DXGI_SWAP_CHAIN_DESC sd{};
    chain->GetDesc(&sd);
    Hooks::g_Hwnd = sd.OutputWindow;

    ID3D11Texture2D* backBuf = nullptr;
    chain->GetBuffer(0, __uuidof(ID3D11Texture2D),
                     reinterpret_cast<void**>(&backBuf));
    Hooks::g_Device->CreateRenderTargetView(backBuf, nullptr, &Hooks::g_RTV);
    backBuf->Release();

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;

    ImGui_ImplWin32_Init(Hooks::g_Hwnd);
    ImGui_ImplDX11_Init(Hooks::g_Device, Hooks::g_Context);

    ImGui::StyleColorsDark();
    auto& style = ImGui::GetStyle();
    style.WindowRounding    = 6.f;
    style.FrameRounding     = 4.f;
    style.GrabRounding      = 4.f;
    style.WindowBorderSize  = 1.f;
    // SlarkCT renk paleti
    style.Colors[ImGuiCol_WindowBg]       = ImVec4(0.08f, 0.08f, 0.10f, 0.95f);
    style.Colors[ImGuiCol_Header]         = ImVec4(0.6f,  0.1f,  0.1f,  0.8f);
    style.Colors[ImGuiCol_HeaderHovered]  = ImVec4(0.8f,  0.15f, 0.15f, 0.9f);
    style.Colors[ImGuiCol_CheckMark]      = ImVec4(1.f,   0.3f,  0.3f,  1.f);
    style.Colors[ImGuiCol_SliderGrab]     = ImVec4(0.8f,  0.2f,  0.2f,  1.f);
    style.Colors[ImGuiCol_Button]         = ImVec4(0.6f,  0.1f,  0.1f,  0.8f);
    style.Colors[ImGuiCol_ButtonHovered]  = ImVec4(0.8f,  0.15f, 0.15f, 0.9f);
    style.Colors[ImGuiCol_FrameBg]        = ImVec4(0.15f, 0.15f, 0.18f, 1.f);
    style.Colors[ImGuiCol_TitleBgActive]  = ImVec4(0.5f,  0.08f, 0.08f, 1.f);
}

HRESULT __stdcall Hooks::hkPresent(IDXGISwapChain* chain,
                                    UINT syncInterval, UINT flags) {
    if (!g_ImguiInit) {
        g_Chain = chain;
        InitImgui(chain);
        s_Client     = GetModuleBase("client.dll");
        g_EntityList = ReadPtr(s_Client + Offsets::dwEntityList);
        g_ImguiInit  = true;
    }

    // entity list pointer her frame guncelle
    g_EntityList = ReadPtr(s_Client + Offsets::dwEntityList);
    auto localPawn = ReadPtr(s_Client + Offsets::dwLocalPlayerPawn);

    // skin changer
    SkinChanger::Run(localPawn);

    // imgui frame
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    // view matrix + ekran boyutu
    Matrix4x4 vm = Read<Matrix4x4>(s_Client + Offsets::dwViewMatrix);
    RECT rect{};
    GetClientRect(g_Hwnd, &rect);
    int sw = rect.right  - rect.left;
    int sh = rect.bottom - rect.top;

    // fullscreen overlay
    ImGui::SetNextWindowPos({ 0.f, 0.f });
    ImGui::SetNextWindowSize({ static_cast<float>(sw), static_cast<float>(sh) });
    ImGui::SetNextWindowBgAlpha(0.f);
    ImGui::Begin("##overlay", nullptr,
        ImGuiWindowFlags_NoTitleBar      |
        ImGuiWindowFlags_NoInputs        |
        ImGuiWindowFlags_NoScrollbar     |
        ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoMove          |
        ImGuiWindowFlags_NoResize);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ESP::Run(dl, vm, sw, sh, localPawn);

    ImGui::End();

    // menu ac/kapat — INSERT
    static bool menuOpen = false;
    if (GetAsyncKeyState(VK_INSERT) & 1)
        menuOpen = !menuOpen;

    if (menuOpen) {
        // fare goster
        ImGui::GetIO().MouseDrawCursor = true;

        ImGui::SetNextWindowSize({ 320.f, 500.f }, ImGuiCond_Once);
        ImGui::Begin("SlarkCT", &menuOpen);

        // --- ESP ---
        if (ImGui::CollapsingHeader("ESP", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Checkbox("Aktif##esp",       &ESP::cfg.enabled);
            ImGui::Checkbox("Kutu",             &ESP::cfg.showBox);
            ImGui::Checkbox("Can Bari",         &ESP::cfg.showHealth);
            ImGui::Checkbox("HP Yazi",          &ESP::cfg.showName);
            ImGui::Checkbox("Takim Kontrolu",   &ESP::cfg.teamCheck);
        }

        ImGui::Separator();

        // --- Skin Changer ---
        if (ImGui::CollapsingHeader("Skin Changer")) {
            static int  selectedDefIdx = 7; // varsayilan AK47
            static int  paintKit = 0;
            static float wear    = 0.001f;
            static int  seed     = 0;
            static bool stEnabled = false;
            static int  stVal    = 0;

            // silah secici
            if (ImGui::BeginCombo("Silah", WeaponName(selectedDefIdx) ? WeaponName(selectedDefIdx) : "?")) {
                int indices[] = {1,2,3,4,7,8,9,10,11,13,14,16,17,19,
                                 23,24,25,26,27,28,29,30,32,33,34,35,
                                 36,38,39,40,60,61,63,64};
                for (int idx : indices) {
                    const char* name = WeaponName(idx);
                    if (!name) continue;
                    bool selected = (selectedDefIdx == idx);
                    if (ImGui::Selectable(name, selected))
                        selectedDefIdx = idx;
                    if (selected) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }

            ImGui::InputInt("Paint Kit",    &paintKit);
            ImGui::SliderFloat("Wear",      &wear, 0.f, 1.f, "%.4f");
            ImGui::InputInt("Seed",         &seed);
            ImGui::Checkbox("StatTrak",     &stEnabled);
            if (stEnabled)
                ImGui::InputInt("StatTrak Deger", &stVal);

            if (ImGui::Button("Uygula", { -1.f, 0.f })) {
                if (selectedDefIdx > 0 && selectedDefIdx < 128) {
                    auto& s     = SkinChanger::skins[selectedDefIdx];
                    s.enabled   = true;
                    s.paintKit  = paintKit;
                    s.wear      = wear;
                    s.seed      = seed;
                    s.statTrak  = stEnabled ? stVal : -1;
                }
            }
            if (ImGui::Button("Kaldir", { -1.f, 0.f })) {
                if (selectedDefIdx > 0 && selectedDefIdx < 128)
                    SkinChanger::skins[selectedDefIdx] = {};
            }
        }

        ImGui::Separator();
        ImGui::TextDisabled("INSERT = menu  |  END = eject");

        ImGui::End();
    } else {
        ImGui::GetIO().MouseDrawCursor = false;
    }

    ImGui::Render();
    g_Context->OMSetRenderTargets(1, &g_RTV, nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    return oPresent(chain, syncInterval, flags);
}

bool Hooks::Init() {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount       = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage       = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow      = GetForegroundWindow();
    sd.SampleDesc.Count  = 1;
    sd.Windowed          = TRUE;
    sd.SwapEffect        = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device*     tmpDevice = nullptr;
    IDXGISwapChain*   tmpChain  = nullptr;
    D3D_FEATURE_LEVEL fl;

    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        nullptr, 0, D3D11_SDK_VERSION,
        &sd, &tmpChain, &tmpDevice, &fl, nullptr);

    if (FAILED(hr)) return false;

    // IDXGISwapChain vtable[8] = Present
    void** vtable = *reinterpret_cast<void***>(tmpChain);
    oPresent = reinterpret_cast<PresentFn>(vtable[8]);

    tmpDevice->Release();
    tmpChain->Release();

    // vtable patch
    DWORD old;
    VirtualProtect(&vtable[8], sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
    vtable[8] = reinterpret_cast<void*>(hkPresent);
    VirtualProtect(&vtable[8], sizeof(void*), old, &old);

    return true;
}

void Hooks::Shutdown() {
    // oPresent'i geri yaz
    if (g_Chain && oPresent) {
        void** vtable = *reinterpret_cast<void***>(g_Chain);
        DWORD old;
        VirtualProtect(&vtable[8], sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        vtable[8] = reinterpret_cast<void*>(oPresent);
        VirtualProtect(&vtable[8], sizeof(void*), old, &old);
    }

    if (g_ImguiInit) {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        g_ImguiInit = false;
    }

    if (g_RTV)     { g_RTV->Release();     g_RTV     = nullptr; }
    if (g_Context) { g_Context->Release(); g_Context = nullptr; }
    if (g_Device)  { g_Device->Release();  g_Device  = nullptr; }
}
