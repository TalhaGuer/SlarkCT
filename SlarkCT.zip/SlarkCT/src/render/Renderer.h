#pragma once
#include "imgui.h"
#include "../sdk/Entity.h"

namespace Renderer {
    bool WorldToScreen(const Vector3& world, ImVec2& screen,
                       const Matrix4x4& vm, int screenW, int screenH);

    void DrawBox(ImDrawList* dl, ImVec2 head, ImVec2 feet, ImU32 color);
    void DrawHealthBar(ImDrawList* dl, ImVec2 head, ImVec2 feet, int health);
    void DrawName(ImDrawList* dl, ImVec2 head, int health);
}
