#include "Renderer.h"
#include <cstdio>

bool Renderer::WorldToScreen(const Vector3& world, ImVec2& screen,
                              const Matrix4x4& vm, int screenW, int screenH) {
    float w = vm.m[3][0] * world.x + vm.m[3][1] * world.y
            + vm.m[3][2] * world.z + vm.m[3][3];
    if (w < 0.001f) return false;

    float x = vm.m[0][0] * world.x + vm.m[0][1] * world.y
            + vm.m[0][2] * world.z + vm.m[0][3];
    float y = vm.m[1][0] * world.x + vm.m[1][1] * world.y
            + vm.m[1][2] * world.z + vm.m[1][3];

    screen.x = (screenW / 2.f) * (1.f + x / w);
    screen.y = (screenH / 2.f) * (1.f - y / w);
    return true;
}

void Renderer::DrawBox(ImDrawList* dl, ImVec2 head, ImVec2 feet, ImU32 color) {
    float h  = feet.y - head.y;
    float w  = h / 2.f;
    float cx = (head.x + feet.x) / 2.f;

    ImVec2 tl{ cx - w / 2.f, head.y };
    ImVec2 br{ cx + w / 2.f, feet.y };

    // outline (siyah)
    dl->AddRect({ tl.x - 1, tl.y - 1 }, { br.x + 1, br.y + 1 },
                IM_COL32(0, 0, 0, 200), 0.f, 0, 3.f);
    // asil kutu
    dl->AddRect(tl, br, color, 0.f, 0, 1.5f);
}

void Renderer::DrawHealthBar(ImDrawList* dl, ImVec2 head, ImVec2 feet, int health) {
    float h    = feet.y - head.y;
    float w    = h / 2.f;
    float cx   = (head.x + feet.x) / 2.f;
    float barH = h * (health / 100.f);

    float barX = cx - w / 2.f - 7.f;

    // arka plan
    dl->AddRectFilled({ barX - 1.f, feet.y - h - 1.f },
                      { barX + 4.f, feet.y + 1.f },
                      IM_COL32(0, 0, 0, 180));
    // dolu kisim
    ImU32 col = IM_COL32(
        static_cast<int>(255 * (1.f - health / 100.f)),
        static_cast<int>(255 * (health / 100.f)),
        0, 255);
    dl->AddRectFilled({ barX, feet.y - barH },
                      { barX + 3.f, feet.y },
                      col);
}

void Renderer::DrawName(ImDrawList* dl, ImVec2 head, int health) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%d HP", health);
    dl->AddText({ head.x - 12.f, head.y - 14.f },
                IM_COL32(255, 255, 255, 230), buf);
}
