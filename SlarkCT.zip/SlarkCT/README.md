# SlarkCT

CS2 internal hack — ESP + Skin Changer  
Windows only, DX11 present hook, imgui overlay.

## Derleme

### Gereksinimler
- Visual Studio 2022 (Desktop C++ workload)
- imgui submodule

### Adimlar

```bash
git submodule add https://github.com/ocornut/imgui vendor/imgui
```

Visual Studio'da `SlarkCT.sln` ac veya CMake ile:

```bash
cmake -DCMAKE_BUILD_TYPE=Release -B build
cmake --build build
```

Cikti: `SlarkCT.dll`

## Inject

CS2 `LoadLibrary` inject'i bloklıyor — **manual mapping** injector kullan.  
Onerilen: **GH Injector** veya **Process Hacker** (manual map modu).

## Kullanim

| Tus    | Islem          |
|--------|----------------|
| INSERT | Menu ac/kapat  |
| END    | DLL eject      |

## Offset Guncelleme

CS2 guncellendikten sonra `src/sdk/Offsets.h` dosyasini guncelle.  
Guncel offsetler icin: https://github.com/a2x/cs2-dumper

## Onemli Not

Offset'ler derleme tarihine gore gecerlidir.  
Oyun guncellemesi sonrasi ESP calismazsa cs2-dumper'dan yeni offset'leri al,  
sadece `Offsets.h`'i guncelle ve yeniden derle.
