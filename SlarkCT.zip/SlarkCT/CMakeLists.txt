cmake_minimum_required(VERSION 3.20)
project(SlarkCT LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

file(GLOB_RECURSE SOURCES "src/*.cpp")
file(GLOB IMGUI_SOURCES
    "vendor/imgui/*.cpp"
    "vendor/imgui/backends/imgui_impl_dx11.cpp"
    "vendor/imgui/backends/imgui_impl_win32.cpp"
)

add_library(SlarkCT SHARED ${SOURCES} ${IMGUI_SOURCES})

target_include_directories(SlarkCT PRIVATE
    src/
    vendor/imgui/
    vendor/imgui/backends/
)

target_link_libraries(SlarkCT PRIVATE d3d11 dxgi)
target_compile_definitions(SlarkCT PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
